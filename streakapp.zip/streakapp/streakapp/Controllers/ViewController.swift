//
//  ViewController.swift
//  streakapp
//
//  Created by Siddharth Dave on 04/10/23.
//

import UIKit

class ViewController: UIViewController {
    
//    @IBOutlet weak var myvieew: UIView!
    @IBOutlet weak var pageController: UIPageControl!
    let task:[String:String] = ["1":"Go for a run","2":"Read a book","3":"Write code","4":"Cook dinner","5":"Learn a new language","6":"Clean the house","7":"Watch a movie","8":"Do yoga","9":"Call a friend","10":"Plan a trip","11":"Study for an exam","12":"Bake cookies","13":"Organize your closet","14":"Take a walk","15":" Play a musical instrument","16":"Visit a museum","17":"Volunteer at a charity","18":"Try a new recipe","19":"Water the plants","20":" Meditate","21":"Write in a journal","22":"Go hiking","23":"Paint a picture","24":"Listen to music","25":"Build a puzzle","26":"Exercise at the gym","27":" Watch a documentary","28":"Take a nap","29":"Visit a park","30":"Do a crossword puzzle","31":"Learn to dance","32":"Read the news","33":"Plan a picnic","34":"Do a DIY project","35":"Explore a new neighborhood","36":"Write poetry","37":"Try a new restaurant","38":" Practice photography","39":"Play chess","40":"Visit a friend","41":" Watch a sunset","42":"Write a thank-you note","43":"Try a new hobby","44":"Attend a workshop","45":"Go fishing","46":"Visit a farmer's market","47":"Take a road trip","48":"Learn to knit","49":"Try a new type of cuisine","50":"Explore a historical site"]
    
    let imgNames:[String] = ["g1","g2","g3","g4","g5","g6","g7","g8","g9","g10"]
    var currentPage = 0
    var sortedKeys:[String] = []
//    var randomImgName = String()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.registerCollectionView()
        sortedKeys = task.keys.sorted(by: { $0.localizedStandardCompare($1) == .orderedAscending })
        pageController.numberOfPages = task.count
        pageController.currentPage = 0

        
        
    }
    
    private func registerCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        collectionView.collectionViewLayout = layout
    }
    
    
    
    @IBAction func pageControlValueChanged(_ sender: UIPageControl) {
        let selectedPage = sender.currentPage
        let indexPath = IndexPath(item: selectedPage, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    @IBAction func screenShotViewTapped(_ sender: Any) {
        let point = (sender as AnyObject).convert(CGPoint.zero, to: collectionView)
        if let indexPath = collectionView.indexPathForItem(at: point) {
            if let cell = collectionView.cellForItem(at: indexPath) as? CollectionViewCell {
                let screenshot = cell.contentView.takeScreenShot()
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "screenshort") as! SSViewController
                
                vc.imageView = screenshot
                vc.modalPresentationStyle = .fullScreen
                
//                navigationController?.pushViewController(vc, animated: true)
                self.present(vc, animated: true)
            }
        }
    }
    
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return task.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? CollectionViewCell else {
            return UICollectionViewCell()
        }
        
        
        if let randomImgName = imgNames.randomElement() {
            cell.bgImg.image = UIImage(named: randomImgName)
        }
        
        cell.days.text = sortedKeys[indexPath.row]
        cell.taskLbl.text = task[sortedKeys[indexPath.row]]
        
//        cell.didSelect = {
//            let screenshoot = self.view.takeScreenShot()
//            
//                
//                let vc = self.storyboard?.instantiateViewController(withIdentifier: "screenshort") as! SSViewController
//            
//            vc.imageView = screenshoot
//                
//                self.present(vc, animated: true)
//                
//            }
        
        return cell
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageIndex = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        pageController.currentPage = pageIndex
    }
}

