//
//  SSViewController.swift
//  streakapp
//
//  Created by Siddharth Dave on 04/10/23.
//

import UIKit

class SSViewController: UIViewController {
    
    @IBOutlet weak var ssImg: UIImageView!
    
    var imageView: UIImage?
    var buttonsHidden = false
    
    @IBOutlet weak var Closeview: UIView!
    
    @IBOutlet weak var shareBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Closeview.layer.cornerRadius = 17
        ssImg.image = imageView
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGesture)
        
        shareBtn.isHidden = buttonsHidden
        Closeview.isHidden = buttonsHidden
        
    }
    
    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            
        buttonsHidden.toggle()
        shareBtn.isHidden = buttonsHidden
        Closeview.isHidden = buttonsHidden
        }
    
    @IBAction func closeBtnTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func shareBtnTapped(_ sender: Any) {
        if let image = ssImg.image {
            let activityVC = UIActivityViewController(activityItems: [image], applicationActivities: nil)
            activityVC.excludedActivityTypes = [.addToReadingList, .postToFacebook, .airDrop, .markupAsPDF, .print]
            self.present(activityVC, animated: true)
        } else {
            print("No image to share")
        }
    }
}


