//
//  extension+UIVIew.swift
//  streakapp
//
//  Created by Siddharth Dave on 04/10/23.
//

import Foundation
import UIKit

extension UIView {
    func takeScreenShot() -> UIImage {
        
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)
        
        drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        if image != nil {
            return image!
        }
        
        return UIImage()
            
    }
}

extension UIImage {
    func cropToRect(rect: CGRect) -> UIImage {
        let imageRef = cgImage?.cropping(to: rect)
        let croppedImage = UIImage(cgImage: imageRef!)
        return croppedImage
    }
}

