//
//  CollectionViewCell.swift
//  streakapp
//
//  Created by Siddharth Dave on 04/10/23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var bgImg: UIImageView!
    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var days: UILabel!
    @IBOutlet weak var taskLbl: UILabel!
    
    var didSelect: (()->Void)?
    
    @IBAction func screenShortView(_ sender: Any) {
        didSelect?()
    }
}
