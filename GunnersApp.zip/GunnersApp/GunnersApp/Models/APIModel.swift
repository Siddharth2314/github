//
//  ApiModels.swift
//  GunnersApp
//
//  Created by Siddharth Dave on 25/08/23.
//

import Foundation


struct APIModel: Codable {
    
    let data : data
}

struct data: Codable {
    
    let clubs : [Clubs]
}

struct Clubs: Codable {
    
    let name : String?
    let icon : String?
}
