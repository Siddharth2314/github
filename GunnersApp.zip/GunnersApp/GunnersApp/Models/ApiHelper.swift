//
//  ApiHelper.swift
//  GunnersApp
//
//  Created by Siddharth Dave on 25/08/23.
//

import Foundation


class ApiHelper {
    
    static let sharedInstance = ApiHelper()
    
    func webServiceCell(completion : @escaping ([Clubs]) -> Void) {
        
        guard let url = ApiUrl.shared.baseUrl else {
            return
        }
        print(url)
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            
            if let error = error {
                print(error)
            }
            
            guard let data = data else { return
                print(data ?? "")
            }
            
            
            if response != nil {
                
                let decoder = JSONDecoder()
                
                do {
                    let respData = try decoder.decode(APIModel.self, from: data )
                    completion(respData.data.clubs)
                } catch{
                    print(error.localizedDescription)
                }
            }
        }
        task.resume()
        
    }
    

}
