//
//  ApiUrl.swift
//  GunnersApp
//
//  Created by Siddharth Dave on 25/08/23.
//

import Foundation


class ApiUrl {
    
    static let shared = ApiUrl()
    
    let baseUrl = URL(string: "https://api2.gunners.com/api-almet/v2.0/NFL/teams")
}
