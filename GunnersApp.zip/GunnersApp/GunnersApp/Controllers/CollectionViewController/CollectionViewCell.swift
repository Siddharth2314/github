//
//  CollectionViewCell.swift
//  GunnersApp
//
//  Created by Siddharth Dave on 25/08/23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var clubName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
