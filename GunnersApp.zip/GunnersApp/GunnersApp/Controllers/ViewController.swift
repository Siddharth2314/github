//
//  ViewController.swift
//  GunnersApp
//
//  Created by Siddharth Dave on 25/08/23.
//

import UIKit
import SDWebImage


class ViewController: UIViewController {
    
    
    @IBOutlet weak var SearchView: UIView!
    
    @IBOutlet weak var searchTF: UITextField!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var apiData:[Clubs] = []
    
    var filterData: [Clubs] = []
    
    var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.searchBAr()
        self.registerCollectionView()
        self.getNEWData()
    }
    
    
    private func getNEWData() {
        
        ApiHelper.sharedInstance.webServiceCell() { [weak self] data in
            guard let self else { return }
            self.apiData = data
            
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
    
    func registerCollectionView() {
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
    }
    
    func searchBAr() {
        
        searchTF.delegate = self
        
        SearchView.layer.cornerRadius = 19
        
        searchTF.attributedPlaceholder = NSAttributedString(
            string: "Search Teams",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        
    }
    
    
    @IBAction func cancelbtn(_ sender: Any) {
        isSearching = false
        searchTF.text = ""
        searchTF.resignFirstResponder()
        collectionView.reloadData()
    }
    @IBAction func searchBtn(_ sender: Any) {
       searchTF.becomeFirstResponder()
    }
    
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource  , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width - 55 ) / 2, height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if isSearching {
            return filterData.count
        }
        else {
            return apiData.count
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell else {
            return UICollectionViewCell() }
        
        if isSearching {
            cell.clubName.text = filterData[indexPath.row].name
            let imgIcon = URL(string: filterData[indexPath.row].icon ?? "")
            cell.iconImage.sd_setImage(with: imgIcon)
        }
        else {
            cell.clubName.text = apiData[indexPath.row].name
            let imgIcon = URL(string: apiData[indexPath.row].icon ?? "")
            cell.iconImage.sd_setImage(with: imgIcon)
        }
        
        
        
        cell.view.layer.cornerRadius = 15
        
        
        return cell
    }
}


extension ViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if searchTF.text!.isEmpty {
            isSearching = false
            self.collectionView.reloadData()
        }
        else {
            isSearching = true
            let searchText = searchTF.text! + string
            
            filterData = (apiData.filter {
                (($0.name!).localizedCaseInsensitiveContains(searchText))})
            self.collectionView.reloadData()
        }
        return true
        
    }
    
}


