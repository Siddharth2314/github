//
//  SaveModel.swift
//  AthenticationFormRealm
//
//  Created by EMP on 13/10/2023.
//

import Foundation
import RealmSwift

//class Login: Object {
//    @objc dynamic var lguser = ""
//    @objc dynamic var lgpass = ""
//}
