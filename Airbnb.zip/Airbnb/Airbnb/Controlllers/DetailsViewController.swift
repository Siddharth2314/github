//
//  DetailsViewController.swift
//  Airbnb
//
//  Created by EMP on 12/10/2023.
//

import UIKit
import SDWebImage

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var dtlViewSpace: UILabel!
    @IBOutlet weak var dtlViewHostSince: UILabel!
    @IBOutlet weak var dtlViewHostName: UILabel!
    @IBOutlet weak var dtlViewHostImg: UIImageView!
    @IBOutlet weak var dtlViewHouseRule: UILabel!
    @IBOutlet weak var dtlViewSummary: UILabel!
    @IBOutlet weak var dtlViewDescription: UILabel!
    @IBOutlet weak var dtlViewPrice: UILabel!
    @IBOutlet weak var dtlViewName: UILabel!
    @IBOutlet weak var dtlViewImg: UIImageView!
    
    var propertyImg = ""
    var propertyName: String?
    var propertyPrice: Int?
    var propertyDescription: String?
    var propertySummary: String?
    var propertyRules: String?
    var hostImg = ""
    var hostName: String?
    var hostSince: String?
    var propertuSpace: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.details()
        
    }
    
    private func details() {
        
        dtlViewImg.sd_setImage(with: URL(string: propertyImg), placeholderImage: UIImage(named: "no_image"), context: .none)
        dtlViewImg.layer.cornerRadius = 10
        
        dtlViewName.text = propertyName
        dtlViewPrice.text = "Nightly Rate : \(propertyPrice?.formatted(.currency(code: "USD")) ?? "")"
        dtlViewDescription.text = "Description:\(propertyDescription ?? "")"
        dtlViewSummary.text = "Summary:\(propertySummary ?? "")"
        if propertuSpace == nil {
            dtlViewHouseRule.text = ""
        } else {
            dtlViewHouseRule.text = "House Rules:\(propertyRules ?? "")"
        }
        
        if propertuSpace == nil {
            dtlViewSpace.textAlignment = .center
        } else {
            dtlViewSpace.textAlignment = .left
            dtlViewSpace.text = "Space:\(propertuSpace ?? "")"
        }
        
        
        let placeholderImage: UIImage?
        if traitCollection.userInterfaceStyle == .dark {
            placeholderImage = UIImage(named: "user-2")
        } else {
            placeholderImage = UIImage(named: "user")
        }
        
        dtlViewHostImg.sd_setImage(with: URL(string: hostImg), placeholderImage: placeholderImage, context: nil)
        dtlViewHostName.text = hostName
        dtlViewHostSince.text = "Hosting since: \(hostSince ?? "")"
    }
    
}
