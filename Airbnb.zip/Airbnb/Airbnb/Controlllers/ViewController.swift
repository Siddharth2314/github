//
//  ViewController.swift
//  Airbnb
//
//  Created by EMP on 12/10/2023.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {
    
    var apidata = [AirbnbListing]()
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.registerTableViewController()
        self.getData()
    }
    

    private func getData() {
        
        ApiHelper.sharedInstance.serviceCall { [weak self] allData in
            guard let self else {
                return
            }
            self.apidata = allData
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
        
    }
    
    private func registerTableViewController() {
        
        tableView.delegate = self
        tableView.dataSource = self
    
        //tableView.layer.cornerRadius = 10
        
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
    }

}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apidata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell else {
            return UITableViewCell()
        }
//        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .none
    
        cell.tblCellname.text = apidata[indexPath.row].name
        cell.tblCelldescription.text = apidata[indexPath.row].description
        cell.tblCelldescription.numberOfLines = 0
        cell.tblCelldescription.textColor = UIColor(named: "arrow")
        
        let image = apidata[indexPath.row].thumbnail_url ?? ""
        
        cell.tblCellimage.sd_setImage(with: URL(string: image))
        cell.tblCellimage.layer.cornerRadius = 10
        cell.mycontentView.layer.cornerRadius = 10
        
        cell.tblCellimage.sd_setImage(with: URL(string: image), placeholderImage: UIImage(named: "no_image"), context: .none)
        
        cell.mycontentView.backgroundColor = UIColor(named: "tableCell")
        
        cell.tblCellname.textColor = UIColor(named: "tableLabelName")
        if traitCollection.userInterfaceStyle == .dark {
            cell.arrowImg.image = UIImage(named: "greater-than-4")
            } else {
                cell.arrowImg.image = UIImage(named: "greater-than-3")
            }
        
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "detailsVC") as? DetailsViewController else { return }
        
//        let backButton = UIBarButtonItem()
//        backButton.title = apidata[indexPath.row].name
//        backButton.width = view.frame.width
//        navigationItem.backBarButtonItem = backButton
        
        vc.propertyImg = apidata[indexPath.row].xl_picture_url ?? ""

        vc.hostImg = apidata[indexPath.row].host_picture_url ?? ""
        
        vc.propertyName = apidata[indexPath.row].name
        vc.propertyPrice = apidata[indexPath.row].price
        vc.propertyDescription = apidata[indexPath.row].description
        vc.propertySummary = apidata[indexPath.row].summary
        vc.propertyRules = apidata[indexPath.row].house_rules
        vc.hostName = apidata[indexPath.row].host_name
        vc.hostSince = apidata[indexPath.row].host_since
        vc.propertuSpace = apidata[indexPath.row].space
        
        
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    

}

