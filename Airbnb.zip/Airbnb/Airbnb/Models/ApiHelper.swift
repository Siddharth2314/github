//
//  ApiHelper.swift
//  Airbnb
//
//  Created by EMP on 12/10/2023.
//

import Foundation


class ApiHelper {
    
    static let sharedInstance = ApiHelper()
    
    func serviceCall( completion: @escaping ([AirbnbListing]) -> Void ) {
        
        guard let url = ApiUrl.shared.baseUrl else {
            return
        }
        print(url)
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            
            if let error = error {
                print("Error in : \(error)")
            }
            
            guard let data = data else { return
                print(data ?? "")
            }
            
            if response != nil {
                
                let decoder = JSONDecoder()
                do {
                    let resdata = try decoder.decode(AirbnbListingResponse.self, from: data)
                    completion(resdata.results)
                    print(resdata)
                } catch {
                    print(error.localizedDescription)
                }
                
            }
            
        }
        task.resume()
    }
    
   
    
    
}
