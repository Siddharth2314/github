//
//  ApiUrl.swift
//  Airbnb
//
//  Created by EMP on 12/10/2023.
//

import Foundation


class ApiUrl {
    
    static let shared = ApiUrl()
    
    let baseUrl = URL(string: "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/airbnb-listings/records?limit=100&refine=city%3A%22New%20York%22&refine=room_type%3A%22Entire%20home%2Fapt%22")
}
