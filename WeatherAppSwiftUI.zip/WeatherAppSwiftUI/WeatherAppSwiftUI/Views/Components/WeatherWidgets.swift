//
//  WeatherWidgets.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI

struct WeatherWidgets: View {
    var forecast: List?
    var searchText: String
    
    var body: some View {
        ZStack(alignment: .bottom) {
            //MARK: Trapezoid
            Trapezoid()
                .fill(Color.weatherWidgetBackground)
                .frame(width: 342,height: 174)
            //MARK: Content
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 8) {
                    //MARK: Forecast Temperature
                    Text(String(format: "%.2f°C", forecast?.main.temp ?? 0))
                        .font(.system(size: 30))
                        .lineLimit(1)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        //MARK: Forecast Temperature Range
                        Text("H:\(Int(forecast?.main.tempMax ?? 0))°C  L:\(Int(forecast?.main.tempMin ?? 0))°C")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                        
                        //MARK: Forecast Location
                        if searchText != "" {
                            Text(searchText)
                                .font(.body)
                                .lineLimit(1)
                        } else {
                            Text("Ahmedabad")
                                .font(.body)
                                .lineLimit(1)
                        }
                    }
                }
                Spacer()
                VStack(alignment: .trailing,spacing: 0) {
                    //MARK: Forecast Large Icon
                    
                    if let weather = forecast?.weather.first {
                        Image("\(weather.icon) large")
                            .padding(.trailing, 4)
                    } else {
                        Image(systemName: "cloud.fill")
                            .foregroundColor(.white)
                            .padding(.trailing, 4)
                    }
                    
                    
                    //MARK: Weather
                    Text(forecast?.weather.first?.description.rawValue ?? "")
                        .font(.footnote)
                        .padding(.trailing, 24)
                }
            }
            .foregroundColor(.white)
            .padding(.bottom, 20)
            .padding(.leading, 20)
        }
        .frame(width: 342, height: 184, alignment: .bottom)
    }
}

struct WeatherWidgets_Previews: PreviewProvider {
    static var previews: some View {
        WeatherWidgets(searchText: "Ahmedabad")
            .preferredColorScheme(.dark)
    }
}
