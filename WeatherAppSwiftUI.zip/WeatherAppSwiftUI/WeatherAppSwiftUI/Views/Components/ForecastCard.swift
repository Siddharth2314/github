//
//  ForecastCard.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI

struct ForecastCard: View {
    var selection: Int = 0
    var forecast: List?
    var forecasts: CurrentApiModel?
    var formattedTime: String {
            let dateString = forecast?.dtTxt ?? ""
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

            if let date = dateFormatter.date(from: dateString) {
                let timeFormatter = DateFormatter()
                timeFormatter.dateFormat = "h a"
                return timeFormatter.string(from: date)
            } else {
                return "Invalid time"
            }
        }
    
    var formattedDateTime: String {
            let dateString = forecast?.dtTxt ?? ""
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

            if let date = dateFormatter.date(from: dateString) {
                let dateAndTimeFormatter = DateFormatter()
                dateAndTimeFormatter.dateFormat = "d MMM"
                return dateAndTimeFormatter.string(from: date)
            } else {
                return "Invalid time"
            }
        }
    
    var currentTime: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h a"
        return dateFormatter.string(from: Date())
    }
    
    var currentDate: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM"
        return dateFormatter.string(from: Date())
    }

    
    var body: some View {
        ZStack {
            
            //MARK: Card
            RoundedRectangle(cornerRadius: 30)
                .fill(Color.forecastCardBackground.opacity( 0.2))
                .frame(width: 60, height: 146)
                .shadow(color: .black.opacity(0.25),radius: 10,x: 5, y: 4)
                .overlay {
                    //MARK: Card Border
                    RoundedRectangle(cornerRadius: 30)
                        .strokeBorder(.white.opacity( 0.2))
                        .blendMode(.overlay)
                }
                .innerShadow(shape: RoundedRectangle(cornerRadius: 30), color: .white.opacity(0.25), linewidth: 1, offsetX: 1, offsetY: 1, blur: 0, blendMode: .overlay)
            
            //MARK: Content
            
            if selection == 0 {
                VStack(spacing: 16) {
                    //MARK: Forecast Date
                    VStack(spacing: 3) {
                        
                        Text(formattedTime)
                            .font(.subheadline.weight(.semibold))
                        
                        Text(formattedDateTime)
                            .font(.system(size: 10).weight(.semibold))
                    }
                    
                    VStack(spacing: -4) {
                        //MARK: Forecast Small Icon
                        if let weather = forecast?.weather.first {
                            Image("\(weather.icon) small")
                        } else {
                            Image(systemName: "cloud.fill")
                                .foregroundColor(.white)
                        }
        
                        //MARK: Forecast Probability
                        Text(String(format: "%.2f",forecast?.wind.speed ?? 0))
                            .font(.system(size: 10).weight(.semibold))
                            .foregroundColor(Color.probabilityText)
                            .opacity(forecast?.main.temp ?? 0 > 0 ? 1 : 0)
                    }
                    .frame(height: 42)
                    
                    //MARK: Forecast Temperature
                    Text("\(Int(forecast?.main.tempMin ?? 0))°C")
                        .font(.system(size: 10).bold())
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 16)
            .frame(width: 60,height: 146)
            } else {  // Display current weather data (from 'forecasts') here
                if let currentWeather = forecasts {
                    VStack(spacing: 16) {
                        //MARK: Forecast Date
                        VStack(spacing: 3) {
                            // Date and time formatting
                            Text(currentTime)
                                .font(.system(size: 14).weight(.semibold))
                            Text(currentDate)
                                .font(.system(size: 10).weight(.semibold))
                        }
                        
                        // Display current weather icon, wind speed, and temperature
                        VStack(spacing: -4) {
                            if let weather = currentWeather.weather.first {
                                Image("\(weather.icon) small")
                            } else {
                                Image(systemName: "cloud.fill")
                                    .foregroundColor(.white)
                            }
                            Text(String(format: "%.2f", currentWeather.wind.speed))
                                .font(.system(size: 10).weight(.semibold))
                                .foregroundColor(Color.probabilityText)
                                .opacity(currentWeather.main.temp > 0 ? 1 : 0)
                        }
                        .frame(height: 42)
                        
                        // Display current temperature
                        Text("\(Int(currentWeather.main.tempMin))°C")
                            .font(.system(size: 10).bold())
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 16)
                    .frame(width: 60, height: 146)
                }
                // Handle the case where current weather data is not available
                else {
                    Text("Current weather data not available")
                        .font(.headline)
                        .foregroundColor(.red)
                        .padding()
                }
            }   
            
        }
    }
}

struct ForecastCard_Previews: PreviewProvider {
    static var previews: some View {
        ForecastCard()
    }
}
