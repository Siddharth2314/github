//
//  WeatherView.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI

struct WeatherView: View {
    @StateObject var weatherViewModel = WeatherViewModel()
    @State private var searchText = ""
    
    //    var searchResult: [List] {
    //        if searchText.isEmpty {
    //            return apidata ?? []
    //        } else {
    //            return apidata ?? []
    //        }
    //    }
    var body: some View {
        ZStack {
            //MARK: Background
            Color.background
                .ignoresSafeArea()
            
            //MARK: Weather Widgets
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    if let weatherData = weatherViewModel.weatherData {
                        ForEach(weatherData.list ?? []) { forecast in
                            WeatherWidgets(forecast: forecast, searchText: searchText)
                        }
                    } else {
                        Text("Loading...")
                    }
                }
            }
            .safeAreaInset(edge: .top) {
                EmptyView()
                    .frame(height: 110)
            }
        }
        .onChange(of: searchText) { newSearchText in
                    weatherViewModel.fetchWeatherData(searchText: newSearchText)
                }
        .overlay {
            //MARK: Navigation Bar
            NavigationBar(searchText: $searchText)
        }
        .navigationBarHidden(true)
//                .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search for a city or airport")
        .onAppear {
            weatherViewModel.fetchWeatherData(searchText: searchText)
        }
    }
}

struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherView()
            .preferredColorScheme(.dark)
    }
}
