//
//  ForecastView.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI

struct ForecastView: View {
    @StateObject var weatherViewModel = WeatherViewModel()
    @StateObject var currentViewModel = CurrentWeatherViewModel()
    
    var bottomSheetTranslationProrated: CGFloat = 1
    @State private var selection = 0
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                SegmentedControl(selection: $selection)
                //MARK: Forecast Cards
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        
                        
                        if selection == 0 {
                            if let weatherData = weatherViewModel.weatherData {
                                ForEach(weatherData.list ?? []) { item in
                                    ForecastCard(selection: selection, forecast: item)
                                    //                                    Text("\(selection)")
                                }
                                
                                .transition(.offset(x:  -430))
                            } else {
                                Text("Loading...")
                            }
                        } else if selection == 1 {
                            if let currentWeatherData = currentViewModel.currentweatherData {
                                ForEach([currentWeatherData]) { forecast in
                                    ForecastCard(selection: selection, forecasts: forecast)
                                    //                                        Text("\(selection)")
                                }
                                .transition(.offset(x: -430))
                            } else {
                                Text("Loading...")
                            }
                        }
                        
                    }
                }
                .padding(.vertical, 20)
            }
            .padding(.horizontal, 20)
            
            //MARK: ForeCast Widgets
            Image ("Forecast Widgets")
                .opacity(bottomSheetTranslationProrated)
            
        }
        //        .background(Blur(radius: 25,opaque: true))
        .backgroundBlur(radius: 25, opaque: true)
        .background(Color.bottomSheetBackground)
        .clipShape(RoundedRectangle(cornerRadius: 44))
        .innerShadow(shape: RoundedRectangle(cornerRadius: 44), color: Color.bottomSheetBorderMiddle, linewidth: 1, offsetX: 0 ,offsetY: 1, blur: 0, blendMode: .overlay, opacity: 1 - bottomSheetTranslationProrated)
        .overlay {
            // MARK: Bottom Sheet Separator
            
            Divider()
                .blendMode(.overlay)
                .background(Color.bottomSheetBorderTop)
                .frame(maxHeight: .infinity, alignment: .top)
                .clipShape((RoundedRectangle(cornerRadius: 44)))
        }
        
        .overlay {
            //MARK: Drag Indicator
            RoundedRectangle(cornerRadius: 10)
                .fill(.black.opacity(0.3))
                .frame(width: 48, height: 5)
                .frame(height: 20)
                .frame(maxHeight: .infinity, alignment: .top)
        }
        .onAppear {
            weatherViewModel.fetchWeatherData(searchText: "Ahmedabad")
        }
        .onAppear {
            currentViewModel.fetchCurrentWeatherData()
        }
        
    }
}

struct ForecastView_Previews: PreviewProvider {
    static var previews: some View {
        ForecastView()
            .background(Color.background)
            .preferredColorScheme(.dark)
    }
}
