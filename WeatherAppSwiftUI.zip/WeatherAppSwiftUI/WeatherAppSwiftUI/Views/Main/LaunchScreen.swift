//
//  LaunchScreen.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 18/10/2023.
//

import SwiftUI

struct LaunchScreen: View {
    @State private var isActive = false
    @State private var imageIndex = 0
    @State private var opacity: Double = 0.0

    let imageNames = ["cloud", "sun", "overcast"]
    
    var body: some View {
        if isActive {
            HomeView()
        } else {
            VStack {
                VStack {
                    Image(imageNames[imageIndex])
                        .resizable()
                        .frame(width: 80, height: 80)
                        .opacity(opacity)
                    Text("Weather App")
                        .font(.system(size: 26))
                        .foregroundColor(.white.opacity(0.80))
                }
                .onAppear {
                    withAnimation(Animation.easeIn(duration: 1.0)) {
                        self.opacity = 1.0
                    }
                }
            }
            .onAppear {
                scheduleNextImage()
            }
        }
    }
    
    func scheduleNextImage() {
        if imageIndex < imageNames.count - 1 {
            Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { _ in
                withAnimation(Animation.easeOut(duration: 1.0)) {
                    self.opacity = 0.0
                }
                self.imageIndex += 1
                Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { _ in
                    withAnimation(Animation.easeIn(duration: 1.0)) {
                        self.opacity = 1.0
                    }
                    scheduleNextImage()
                }
            }
        } else {
            Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { _ in
                withAnimation(Animation.easeOut(duration: 1.0)) {
                    self.opacity = 0.0
                }
                Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { _ in
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

struct LaunchScreen_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreen()
            .preferredColorScheme(.dark)
    }
}
