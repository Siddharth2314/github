//
//  HomeView.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI
import BottomSheet

enum BottomSheetPosition: CGFloat, CaseIterable {
    case top = 0.83 // 702 / 844
    case middle = 0.385 // 325 / 844
}

struct HomeView: View {
    var forecasts: CurrentApiModel?
    @StateObject var currentViewModel = CurrentWeatherViewModel()
    @State private var city = "Ahmedabad"
    @State var bottomSheetPosition: BottomSheetPosition = .middle
    @State var bottomSheetTranslation: CGFloat = BottomSheetPosition.middle.rawValue
    @State var hasDragged: Bool = false
    
    var bottomSheetTranslationProprated: CGFloat {
        (bottomSheetTranslation - BottomSheetPosition.middle.rawValue) / (BottomSheetPosition.top.rawValue - BottomSheetPosition.middle.rawValue)
    }
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                let screenHeight = geometry.size.height + geometry.safeAreaInsets.top + geometry.safeAreaInsets.bottom
                
                let imageOffset = screenHeight + 36
                
                ZStack {
                   
                    // MARK: Background Color
                    Color.background
                        .ignoresSafeArea()
                    
                    //MARK: Background Image
                    
                    Image("Background")
                        .resizable()
                        .ignoresSafeArea()
                        .offset(y: -bottomSheetTranslationProprated * imageOffset)
                    
                    //MARK: House Image
                    
                    Image("House")
                        .frame(maxHeight: .infinity, alignment: .top)
                        .padding(.top, 257)
                        .offset(y: -bottomSheetTranslationProprated * imageOffset)
                    
                    //MARK: Current Weather
                    if let weatherData = currentViewModel.currentweatherData {
                        VStack(spacing: -10 * (1 - bottomSheetTranslationProprated)) {
                            Text(city)
                                .font(.largeTitle)
                            
                            VStack {
                                Text(attributedString)
                                
//                                Text("\(currentViewModel.currentweatherData?.weather.first?.description.rawValue ?? "")")
//                                    .font(.title3.weight(.semibold))
//                                    .foregroundColor(.secondary)
                                Text("H:\(Int(weatherData.main.tempMax))°C    L:\(Int(weatherData.main.tempMin))°C")
                                    .font(.title3.weight(.semibold))
                                    .opacity(1 - bottomSheetTranslationProprated)
                            }
                            Spacer()
                        }
                        .padding(.top,51)
                        .offset(y: -bottomSheetTranslationProprated * 46)
                    }
                    //MARK: Bottom Sheet
                    
                    BottomSheetView(position: $bottomSheetPosition) {
    //                    Text(bottomSheetPosition.rawValue.formatted())
//                        Text(bottomSheetTranslationProprated.formatted())
                        
                    } content: {
                        ForecastView(bottomSheetTranslationProrated: bottomSheetTranslationProprated)
                    }
                    .onBottomSheetDrag { translation in
                        bottomSheetTranslation = translation / screenHeight
                        
                        withAnimation(.easeInOut) {
                            
                            if bottomSheetPosition == BottomSheetPosition.top {
                                hasDragged = true
                            } else {
                                hasDragged = false
                            }
                        }
                    }
                    
                    //MARK: Tab Bar
                    TabBar(action: {
                        bottomSheetPosition = .top
                    })
                    .offset(y: bottomSheetTranslationProprated * 115)
                }
            }
            .navigationBarHidden(true)
            .onAppear{
                currentViewModel.fetchCurrentWeatherData()
            }
        }
    }
    
    private var attributedString: AttributedString {
        var string = AttributedString("\(currentViewModel.currentweatherData?.wind.speed ?? 0)°C" + (hasDragged ? " | " : "\n ") + (hasDragged ? "\(currentViewModel.currentweatherData?.weather.first?.description.rawValue ?? "") " : "\t\t\t\(currentViewModel.currentweatherData?.weather.first?.description.rawValue ?? "") "))
        
        if let temp = string.range(of: "\(currentViewModel.currentweatherData?.wind.speed ?? 0)°C") {
            string[temp].font = .system(size: (96 - (bottomSheetTranslationProprated * (96 - 20))), weight: hasDragged ? .semibold : .thin)
            string[temp].foregroundColor = hasDragged ? .secondary : .primary
        }
        
        if let pipe = string.range(of: " | ") {
            string[pipe].font = .title3.weight(.semibold)
            string[pipe].foregroundColor = .secondary.opacity(bottomSheetTranslationProprated)
        }
        
        if let weather = string.range(of: "\(currentViewModel.currentweatherData?.weather.first?.description.rawValue ?? "")") {
            string[weather].font = .title3.weight(.semibold)
            string[weather].foregroundColor = .secondary
            
        }
        return string
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .preferredColorScheme(.dark)
    }
}
