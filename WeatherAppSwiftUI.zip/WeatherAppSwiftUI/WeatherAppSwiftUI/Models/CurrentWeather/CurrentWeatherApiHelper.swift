//
//  CurrentWeatherApiHelper.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 17/10/2023.
//
import Foundation
import Combine

class CurrentWeatherViewModel: ObservableObject {
    @Published var currentweatherData: CurrentApiModel?

    private var cancellables: Set<AnyCancellable> = []

    func fetchCurrentWeatherData() {
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=23.0225&lon=72.5714&appid=0ab6554626465c442b5d8699c01ed801") else {
            return
        }

        URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: CurrentApiModel.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    print("Error: \(error)")
                }
            } receiveValue: { [weak self] data in
                self?.currentweatherData = data
            }
            .store(in: &cancellables)
    }
}
