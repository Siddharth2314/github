//
//  ApiModels.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 17/10/2023.
//

import Foundation


struct CurrentApiModel: Codable, Identifiable {
    let id: Double // Use Int or Double to match the numeric "id" in JSON
    let weather: [CurrentWeathers]
    let main: CurrentMainClass
    let wind: CurrentWind
    
    enum CodingKeys: String, CodingKey {
        case id
        case main
        case weather
        case wind
    }
}

struct CurrentWind: Codable {
    let speed: Double
}

struct CurrentMainClass: Codable {
    let temp: Double
    let tempMin: Double
    let tempMax: Double
    enum CodingKeys: String, CodingKey {
           case temp
           case tempMin = "temp_min"
           case tempMax = "temp_max"
       }
}

struct CurrentWeathers: Codable, Identifiable {
    
    let id: Double?
    let description: CurrentDescription
    
    var icon: String {
        switch description {
            case .brokenClouds:
                return "Sun cloud angled rain"
            case .clearSky:
                return "Sun cloud mid rain"
            case .fewClouds:
                return "Moon cloud fast wind"
            case .overcastClouds:
                return "Moon cloud mid rain"
            case .scatteredClouds:
                return "Sun cloud mid rain"
            default:
                return "unknow"
        }
    }
}

enum CurrentDescription: String, Codable {
    case brokenClouds = "broken clouds" //Cloudy
    case clearSky = "clear sky" // Clear
    case fewClouds = "few clouds" //Fast Wind
    case overcastClouds = "overcast clouds" //Mid Rain
    case scatteredClouds = "scattered clouds" //Sunny
    case lightrain = "light rain"
    
    case unknown = "Unknown" // Default value for unknown descriptions
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let rawValue = try? container.decode(String.self) {
            self = CurrentDescription(rawValue: rawValue) ?? .unknown
        } else {
            self = .unknown
        }
    }
}
