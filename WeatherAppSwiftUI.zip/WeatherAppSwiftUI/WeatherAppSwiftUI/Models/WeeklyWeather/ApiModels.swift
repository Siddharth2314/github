//
//  ApiModels.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 17/10/2023.
//

import Foundation

struct ApiModel: Codable {
    let list: [List]?
}

struct List: Codable, Identifiable {
    let id: Int// Use Int for the "dt" field
    let dtTxt: String
    let main: MainClass
    let weather: [Weathers]
    let wind: Wind
    
    enum CodingKeys: String, CodingKey {
        case id = "dt"
        case dtTxt = "dt_txt"
        case main
        case weather
        case wind
    }
}

struct Wind: Codable {
    let speed: Double
}
struct MainClass: Codable {
    let temp: Double
    let tempMin: Double
    let tempMax: Double
    enum CodingKeys: String, CodingKey {
        case temp
        case tempMin = "temp_min"
        case tempMax = "temp_max"
    }
}

struct Weathers: Codable {
    
    let description: Description
    
    var icon: String {
        switch description {
        case .brokenClouds:
            return "Sun cloud angled rain"
        case .clearSky:
            return "Sun cloud mid rain"
        case .fewClouds:
            return "Moon cloud fast wind"
        case .overcastClouds:
            return "Moon cloud mid rain"
        case .scatteredClouds:
            return "Sun cloud mid rain"
        case .lightrain:
            return "Sun cloud mid rain"
        default:
            return "unknow"
        }
    }
}

enum Description: String, Codable {
    case brokenClouds = "broken clouds" //Cloudy
    case clearSky = "clear sky" // Clear
    case fewClouds = "few clouds" //Fast Wind
    case overcastClouds = "overcast clouds" //Mid Rain
    case scatteredClouds = "scattered clouds" //Sunny
    case lightrain = "light rain"
    
    case unknown = "Unknown" // Default value for unknown descriptions
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let rawValue = try? container.decode(String.self) {
            self = Description(rawValue: rawValue) ?? .unknown
        } else {
            self = .unknown
        }
    }
}


