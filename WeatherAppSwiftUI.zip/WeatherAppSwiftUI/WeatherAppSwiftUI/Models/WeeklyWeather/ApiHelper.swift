//
//  ApiHelper.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 17/10/2023.
//

import Foundation
import Combine

class WeatherViewModel: ObservableObject {
    @Published var weatherData: ApiModel?

    private var cancellables: Set<AnyCancellable> = []

    func fetchWeatherData(searchText: String) {
        let queryText = searchText.isEmpty ? "Ahmedabad" : searchText
        guard let url = URL(string: "http://api.openweathermap.org/data/2.5/forecast?q=\(queryText)&appid=0ab6554626465c442b5d8699c01ed801") else {
            return
        }
//        print(url)

        URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: ApiModel.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    print("Error: \(error)")
                }
            } receiveValue: { [weak self] data in
                self?.weatherData = data
            }
            .store(in: &cancellables)
    }
}
