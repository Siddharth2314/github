//
//  ApiURL.swift
//  WeatherAppSwiftUI
//
//  Created by EMP on 16/10/2023.
//

import SwiftUI

class ApiUrl {
    
    static let shared = ApiUrl()
    
    let key = "d73c15686c364613bde120529231610"
    let baseURl = URL(string: "https://api.weatherapi.com/v1/forecast.json")
}
