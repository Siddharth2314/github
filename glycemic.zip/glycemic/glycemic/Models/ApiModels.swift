//
//  ApiModels.swift
//  glycemic
//
//  Created by EMP on 10/10/2023.
//

import Foundation

struct ApiModel: Codable {
    let data: [[String]]
}
