//
//  ApiUrl.swift
//  glycemic
//
//  Created by EMP on 10/10/2023.
//

import Foundation


class ApiUrl {
    
    static let shared = ApiUrl()
    
    let baseUrl = URL(string: "https://api.npoint.io/2ad2c7cb90facc15223c")
}
